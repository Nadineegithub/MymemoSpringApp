package com.sam.myVault;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyVaultApplicationTests {

	@Test
	void contextLoads() {
	}

}
